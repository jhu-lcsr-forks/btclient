#!/bin/sh

#
# The PowerPanel for Linux Software Uninstallation
#

DAEMON="pwrstatd" 
MATCH_OS=0
RC_DIR=""
START_LN=""
STOP_LN=""

# uppercase to lowercase and search keyword string
OS=`cat /proc/version | grep -i 'suse'`
if [ ${#OS} != 0 ]; then
	MATCH_OS=1
fi

OS=`cat /proc/version | grep -i 'red hat'`
if [ ${#OS} != 0 ]; then
	MATCH_OS=1
fi

OS=`cat /proc/version | grep -i 'ubuntu'`
if [ ${#OS} != 0 ]; then
	MATCH_OS=1
fi

OS=`cat /proc/version | grep -i 'debian'`
if [ ${#OS} != 0 ]; then
	MATCH_OS=1
fi

# have not match any linux OS

# Remove pwrstatd startup registry

if [ $MATCH_OS = 1 ]; then
	if [ -e /sbin/chkconfig ]; then
	    /sbin/chkconfig --level 2345 $DAEMON off
	    /sbin/chkconfig --del $DAEMON
	else 
		  # for ubuntu/debian linux
	    if [ -e /usr/sbin/sysvconfig ]; then
	    		/usr/sbin/sysvconfig --disable $DAEMON	        
	    fi          
	fi
fi

# Stop the pwrstatd process
if [ -e /etc/init.d/$DAEMON ]; then 
	/etc/init.d/$DAEMON stop
fi


# Terminate pwrstatd process forcedly!
CMD=`ps -A | grep pwrstatd`
if [ ${#CMD} != 0 ]; then
	if [ -e /sbin/killproc ]; then
		/sbin/killproc -TERM /usr/sbin/$DAEMON
	else
		set -- $CMD    # set result as varable $1 ~ $9(max)		
		kill -TERM $1	# $1 denote process ID(PID)
	fi		
fi

#
# remove files
#

# link daemon startup script file in runlevel 
for j in 0 1; do
	for i in 2 3 4 5; do	
		if [ $j = 0 ]; then
			RC_DIR="/etc/rc.d/rc$i.d"
		else
			RC_DIR="/etc/rc$i.d"
		fi
		
		START_LN="$RC_DIR/K99$DAEMON"
		STOP_LN="$RC_DIR/S99$DAEMON"
			
		if [ -e $START_LN ]; then
			/bin/rm $START_LN			
		fi
		if [ -e $STOP_LN ]; then			
			/bin/rm $STOP_LN
		fi			
	done
done

# startup control script
if [ -e /etc/init.d/$DAEMON ]; then
	/bin/rm /etc/init.d/$DAEMON
fi

# daemon log file
if [ -e /var/log/pwrstatd.log ]; then
 	/bin/rm /var/log/pwrstatd.log
fi

# daemon device path file
if [ -e /var/pwrstatd.dev ]; then
 	/bin/rm /var/pwrstatd.dev
fi

# daemon ipc file
if [ -e /var/pwrstatd.ipc ]; then
 	/bin/rm /var/pwrstatd.ipc
fi

# Notice a message
/bin/echo "uninstallation accomplish!"
